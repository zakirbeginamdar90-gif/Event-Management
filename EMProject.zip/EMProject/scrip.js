/* =====================================================
   EVENT MANAGEMENT SYSTEM
   HTML + CSS + JAVASCRIPT

   Project:
   EventHub

   Technologies:
   HTML
   CSS
   JavaScript

   Storage:
   Browser localStorage

   Main concept:
   JavaScript Static Methods
   ===================================================== */


/* =====================================================
   EVENT MANAGER CLASS
   ===================================================== */

class EventManager {


    /* =================================================
       GET EVENTS
       ================================================= */

    static getEvents() {

        let events =
            JSON.parse(
                localStorage.getItem("events")
            );


        if (!events) {

            events = [

                {
                    id: 1,

                    name:
                        "College Cultural Fest",

                    date:
                        "2026-10-15",

                    time:
                        "10:00",

                    venue:
                        "College Auditorium",

                    category:
                        "Cultural",

                    description:
                        "A cultural celebration with music, dance and entertainment."
                },


                {
                    id: 2,

                    name:
                        "Technology Workshop",

                    date:
                        "2026-10-20",

                    time:
                        "11:00",

                    venue:
                        "Computer Lab",

                    category:
                        "Workshop",

                    description:
                        "Learn modern technology and practical computer skills."
                },


                {
                    id: 3,

                    name:
                        "Coding Seminar",

                    date:
                        "2026-10-25",

                    time:
                        "09:30",

                    venue:
                        "Seminar Hall",

                    category:
                        "Technical",

                    description:
                        "A seminar covering programming and software development."
                },


                {
                    id: 4,

                    name:
                        "Inter College Sports",

                    date:
                        "2026-11-02",

                    time:
                        "08:00",

                    venue:
                        "College Ground",

                    category:
                        "Sports",

                    description:
                        "Annual sports event featuring multiple competitions."
                },


                {
                    id: 5,

                    name:
                        "Career Development Seminar",

                    date:
                        "2026-11-10",

                    time:
                        "12:00",

                    venue:
                        "Main Hall",

                    category:
                        "Seminar",

                    description:
                        "Learn about careers, interviews and professional development."
                },


                {
                    id: 6,

                    name:
                        "Web Development Workshop",

                    date:
                        "2026-11-18",

                    time:
                        "10:30",

                    venue:
                        "IT Lab",

                    category:
                        "Technical",

                    description:
                        "Practical introduction to modern web development."
                }

            ];


            EventManager.saveEvents(events);

        }


        return events;

    }


    /* =================================================
       SAVE EVENTS
       ================================================= */

    static saveEvents(events) {

        localStorage.setItem(
            "events",
            JSON.stringify(events)
        );

    }


    /* =================================================
       DISPLAY EVENTS
       ================================================= */

    static displayEvents(events = null) {

        const container =
            document.getElementById(
                "eventContainer"
            );


        if (!container) {
            return;
        }


        if (events === null) {

            events =
                EventManager.getEvents();

        }


        container.innerHTML = "";


        if (events.length === 0) {

            container.innerHTML = `

                <div class="no-events">

                    <h3>
                        No Events Found
                    </h3>

                    <p>
                        Try another search or category.
                    </p>

                </div>

            `;

            return;

        }


        events.forEach(
            event => {

                container.innerHTML += `

                    <div class="event-card">

                        <div class="event-top">

                            <span class="category">
                                ${event.category}
                            </span>

                            <h3>
                                ${event.name}
                            </h3>

                        </div>


                        <div class="event-body">

                            <p>
                                <strong>
                                    Date:
                                </strong>

                                ${EventManager.formatDate(event.date)}
                            </p>


                            <p>
                                <strong>
                                    Time:
                                </strong>

                                ${event.time}
                            </p>


                            <p>
                                <strong>
                                    Venue:
                                </strong>

                                ${event.venue}
                            </p>


                            <p>
                                ${event.description}
                            </p>


                            <br>


                            <a href="registration.html"
                               class="btn">

                                Register

                            </a>

                        </div>

                    </div>

                `;

            }
        );

    }


    /* =================================================
       SEARCH EVENTS
       ================================================= */

    static searchEvents() {

        const searchInput =
            document.getElementById(
                "searchInput"
            );


        const categoryFilter =
            document.getElementById(
                "categoryFilter"
            );


        if (
            !searchInput ||
            !categoryFilter
        ) {

            return;

        }


        const keyword =
            searchInput.value
                .toLowerCase()
                .trim();


        const category =
            categoryFilter.value;


        const events =
            EventManager.getEvents();


        const filteredEvents =
            events.filter(
                event => {

                    const matchesSearch =

                        event.name
                            .toLowerCase()
                            .includes(keyword)

                        ||

                        event.description
                            .toLowerCase()
                            .includes(keyword);


                    const matchesCategory =

                        category === "All"

                        ||

                        event.category ===
                        category;


                    return (
                        matchesSearch &&
                        matchesCategory
                    );

                }
            );


        EventManager.displayEvents(
            filteredEvents
        );

    }


    /* =================================================
       SAVE / ADD / UPDATE EVENT
       ================================================= */

    static saveEvent() {

        const name =
            document.getElementById(
                "eventName"
            ).value.trim();


        const date =
            document.getElementById(
                "eventDate"
            ).value;


        const time =
            document.getElementById(
                "eventTime"
            ).value;


        const venue =
            document.getElementById(
                "eventVenue"
            ).value.trim();


        const category =
            document.getElementById(
                "eventCategory"
            ).value;


        const description =
            document.getElementById(
                "eventDescription"
            ).value.trim();


        /* VALIDATION */

        if (
            name === "" ||
            date === "" ||
            time === "" ||
            venue === "" ||
            description === ""
        ) {

            alert(
                "Please fill all event details."
            );

            return;

        }


        let events =
            EventManager.getEvents();


        const editId =
            document.getElementById(
                "editEventId"
            ).value;


        /* UPDATE EVENT */

        if (editId !== "") {

            const index =
                events.findIndex(
                    event =>
                        event.id == editId
                );


            if (index !== -1) {

                events[index] = {

                    id:
                        Number(editId),

                    name:
                        name,

                    date:
                        date,

                    time:
                        time,

                    venue:
                        venue,

                    category:
                        category,

                    description:
                        description

                };

            }


            alert(
                "Event updated successfully!"
            );

        }


        /* ADD NEW EVENT */

        else {

            const newEvent = {

                id:
                    Date.now(),

                name:
                    name,

                date:
                    date,

                time:
                    time,

                venue:
                    venue,

                category:
                    category,

                description:
                    description

            };


            events.push(
                newEvent
            );


            alert(
                "Event added successfully!"
            );

        }


        EventManager.saveEvents(
            events
        );


        EventManager.clearForm();


        EventManager.displayAdminEvents();

    }


    /* =================================================
       EDIT EVENT
       ================================================= */

    static editEvent(id) {

        const events =
            EventManager.getEvents();


        const event =
            events.find(
                item =>
                    item.id == id
            );


        if (!event) {
            return;
        }


        document.getElementById(
            "editEventId"
        ).value =
            event.id;


        document.getElementById(
            "eventName"
        ).value =
            event.name;


        document.getElementById(
            "eventDate"
        ).value =
            event.date;


        document.getElementById(
            "eventTime"
        ).value =
            event.time;


        document.getElementById(
            "eventVenue"
        ).value =
            event.venue;


        document.getElementById(
            "eventCategory"
        ).value =
            event.category;


        document.getElementById(
            "eventDescription"
        ).value =
            event.description;


        document.getElementById(
            "adminFormTitle"
        ).innerText =
            "Edit Event";


        window.scrollTo({

            top: 0,

            behavior: "smooth"

        });

    }


    /* =================================================
       DELETE EVENT
       ================================================= */

    static deleteEvent(id) {

        const confirmation =
            confirm(
                "Are you sure you want to delete this event?"
            );


        if (!confirmation) {
            return;
        }


        let events =
            EventManager.getEvents();


        events =
            events.filter(
                event =>
                    event.id != id
            );


        EventManager.saveEvents(
            events
        );


        EventManager.displayAdminEvents();


        alert(
            "Event deleted successfully!"
        );

    }


    /* =================================================
       DISPLAY ADMIN EVENTS
       ================================================= */

    static displayAdminEvents() {

        const container =
            document.getElementById(
                "adminEventList"
            );


        if (!container) {
            return;
        }


        const events =
            EventManager.getEvents();


        container.innerHTML = "";


        if (events.length === 0) {

            container.innerHTML = `

                <p>
                    No events available.
                </p>

            `;

            return;

        }


        events.forEach(
            event => {

                container.innerHTML += `

                    <div class="admin-event">

                        <h3>
                            ${event.name}
                        </h3>


                        <p>
                            <strong>
                                Category:
                            </strong>

                            ${event.category}
                        </p>


                        <p>
                            <strong>
                                Date:
                            </strong>

                            ${EventManager.formatDate(event.date)}
                        </p>


                        <p>
                            <strong>
                                Time:
                            </strong>

                            ${event.time}
                        </p>


                        <p>
                            <strong>
                                Venue:
                            </strong>

                            ${event.venue}
                        </p>


                        <div class="admin-actions">

                            <button
                                class="edit-btn"
                                onclick="EventManager.editEvent(${event.id})">

                                Edit

                            </button>


                            <button
                                class="delete-btn"
                                onclick="EventManager.deleteEvent(${event.id})">

                                Delete

                            </button>

                        </div>

                    </div>

                `;

            }
        );

    }


    /* =================================================
       CLEAR ADMIN FORM
       ================================================= */

    static clearForm() {

        const editId =
            document.getElementById(
                "editEventId"
            );


        const name =
            document.getElementById(
                "eventName"
            );


        const date =
            document.getElementById(
                "eventDate"
            );


        const time =
            document.getElementById(
                "eventTime"
            );


        const venue =
            document.getElementById(
                "eventVenue"
            );


        const description =
            document.getElementById(
                "eventDescription"
            );


        if (editId) {
            editId.value = "";
        }


        if (name) {
            name.value = "";
        }


        if (date) {
            date.value = "";
        }


        if (time) {
            time.value = "";
        }


        if (venue) {
            venue.value = "";
        }


        if (description) {
            description.value = "";
        }


        const title =
            document.getElementById(
                "adminFormTitle"
            );


        if (title) {

            title.innerText =
                "Add New Event";

        }

    }


    /* =================================================
       FORMAT DATE
       ================================================= */

    static formatDate(date) {

        const dateObject =
            new Date(
                date + "T00:00:00"
            );


        return dateObject.toLocaleDateString(
            "en-IN",
            {

                day: "2-digit",

                month: "short",

                year: "numeric"

            }
        );

    }

}


/* =====================================================
   REGISTRATION MANAGER
   ===================================================== */

class RegistrationManager {


    /* =================================================
       LOAD EVENTS INTO SELECT BOX
       ================================================= */

    static loadEvents() {

        const select =
            document.getElementById(
                "eventSelect"
            );


        if (!select) {
            return;
        }


        const events =
            EventManager.getEvents();


        select.innerHTML = `

            <option value="">
                Select an event
            </option>

        `;


        events.forEach(
            event => {

                select.innerHTML += `

                    <option value="${event.id}">

                        ${event.name}

                    </option>

                `;

            }
        );

    }


    /* =================================================
       REGISTER PARTICIPANT
       ================================================= */

    static register(event) {

        event.preventDefault();


        const name =
            document.getElementById(
                "participantName"
            ).value.trim();


        const email =
            document.getElementById(
                "participantEmail"
            ).value.trim();


        const phone =
            document.getElementById(
                "participantPhone"
            ).value.trim();


        const eventId =
            document.getElementById(
                "eventSelect"
            ).value;


        const attendees =
            document.getElementById(
                "attendees"
            ).value;


        let valid = true;


        /* CLEAR ERRORS */

        document.getElementById(
            "nameError"
        ).innerText = "";


        document.getElementById(
            "emailError"
        ).innerText = "";


        document.getElementById(
            "phoneError"
        ).innerText = "";


        document.getElementById(
            "eventError"
        ).innerText = "";


        /* NAME VALIDATION */

        if (name.length < 3) {

            document.getElementById(
                "nameError"
            ).innerText =
                "Please enter a valid name.";

            valid = false;

        }


        /* EMAIL VALIDATION */

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


        if (
            !emailPattern.test(email)
        ) {

            document.getElementById(
                "emailError"
            ).innerText =
                "Please enter a valid email.";

            valid = false;

        }


        /* PHONE VALIDATION */

        const phonePattern =
            /^[0-9]{10}$/;


        if (
            !phonePattern.test(phone)
        ) {

            document.getElementById(
                "phoneError"
            ).innerText =
                "Phone number must contain 10 digits.";

            valid = false;

        }


        /* EVENT VALIDATION */

        if (eventId === "") {

            document.getElementById(
                "eventError"
            ).innerText =
                "Please select an event.";

            valid = false;

        }


        if (!valid) {
            return;
        }


        /* GET OLD REGISTRATIONS */

        const registrations =
            JSON.parse(
                localStorage.getItem(
                    "registrations"
                )
            ) || [];


        /* CREATE REGISTRATION */

        const registration = {

            id:
                Date.now(),

            name:
                name,

            email:
                email,

            phone:
                phone,

            eventId:
                eventId,

            attendees:
                attendees,

            registrationDate:
                new Date().toLocaleString()

        };


        registrations.push(
            registration
        );


        /* SAVE REGISTRATION */

        localStorage.setItem(
            "registrations",

            JSON.stringify(
                registrations
            )
        );


        /* SUCCESS MESSAGE */

        document.getElementById(
            "registrationMessage"
        ).innerHTML = `

            <div class="success">

                <strong>
                    Registration Successful!
                </strong>

                <br>

                Thank you,
                ${name}.

                Your registration has been saved.

            </div>

        `;


        document.getElementById(
            "registrationForm"
        ).reset();

    }

}


/* =====================================================
   CONTACT MANAGER
   ===================================================== */

class ContactManager {


    static sendMessage(event) {

        event.preventDefault();


        const name =
            document.getElementById(
                "contactName"
            ).value.trim();


        const email =
            document.getElementById(
                "contactEmail"
            ).value.trim();


        const message =
            document.getElementById(
                "contactMessage"
            ).value.trim();


        if (
            name === "" ||
            email === "" ||
            message === ""
        ) {

            document.getElementById(
                "contactResponse"
            ).innerHTML = `

                <div class="error">

                    Please fill all fields.

                </div>

            `;

            return;

        }


        document.getElementById(
            "contactResponse"
        ).innerHTML = `

            <div class="success">

                Your message has been submitted successfully.

            </div>

        `;


        event.target.reset();

    }

}


/* =====================================================
   MOBILE MENU
   ===================================================== */

function toggleMenu() {

    const menu =
        document.querySelector(
            ".nav-links"
        );


    if (menu) {

        menu.classList.toggle(
            "show"
        );

    }

}


/* =====================================================
   PAGE INITIALIZATION
   ===================================================== */

document.addEventListener(
    "DOMContentLoaded",

    function () {


        /* HOME PAGE */

        const homeCount =
            document.getElementById(
                "homeEventCount"
            );


        if (homeCount) {

            const events =
                EventManager.getEvents();


            homeCount.innerText =
                events.length;

        }


        /* EVENT PAGE */

        const eventContainer =
            document.getElementById(
                "eventContainer"
            );


        if (eventContainer) {

            EventManager.displayEvents();

        }


        /* ADMIN PAGE */

        const adminList =
            document.getElementById(
                "adminEventList"
            );


        if (adminList) {

            EventManager.displayAdminEvents();

        }


        /* REGISTRATION PAGE */

        const eventSelect =
            document.getElementById(
                "eventSelect"
            );


        if (eventSelect) {

            RegistrationManager.loadEvents();

        }

    }
);